import { TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, GOOGLE_SCRIPT_URL } from '../config';

// Отправка текстового сообщения в Telegram
async function sendTelegramMessage(text) {
  const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: TELEGRAM_CHAT_ID,
      text,
      parse_mode: 'HTML',
    }),
  });
  if (!response.ok) throw new Error('Telegram message failed');
}

// Отправка фото в Telegram
async function sendTelegramPhoto(photoFile, caption) {
  const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendPhoto`;
  const formData = new FormData();
  formData.append('chat_id', TELEGRAM_CHAT_ID);
  formData.append('photo', photoFile);
  formData.append('caption', caption);
  formData.append('parse_mode', 'HTML');
  const response = await fetch(url, { method: 'POST', body: formData });
  if (!response.ok) throw new Error('Telegram photo failed');
}

// Сохранение данных в Google Sheets через Apps Script
async function saveToGoogleSheets(data) {
  if (!GOOGLE_SCRIPT_URL || GOOGLE_SCRIPT_URL.startsWith('ВАШ')) return;
  const response = await fetch(GOOGLE_SCRIPT_URL, {
    method: 'POST',
    mode: 'no-cors',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return response;
}

// Форматирование сообщения для Telegram
function formatTelegramMessage(data, lang) {
  const isRu = lang === 'ru';
  const positions = {
    dentist:   isRu ? 'Стоматолог' : 'Stomatolog',
    assistant: isRu ? 'Ассистент стоматолога' : 'Stomatolog yordamchisi',
    admin:     isRu ? 'Администратор' : 'Administrator',
    nurse:     isRu ? 'Медсестра' : 'Hamshira',
    marketer:  isRu ? 'Маркетолог' : 'Marketolog',
    other:     isRu ? 'Другое' : 'Boshqa',
  };

  const now = new Date().toLocaleString('ru-RU', { timeZone: 'Asia/Tashkent' });

  return isRu
    ? `🦷 <b>Новая заявка на работу</b>
📅 ${now}

👤 <b>ФИО:</b> ${data.lastName} ${data.firstName} ${data.middleName}
🎂 <b>Дата рождения:</b> ${data.birthDate}
📍 <b>Место рождения:</b> ${data.birthPlace}

🎓 <b>Образование:</b> ${data.institution}
📚 <b>Специальность:</b> ${data.specialty}

💼 <b>Последнее место работы:</b> ${data.lastWork}
🏷 <b>Должность:</b> ${data.lastPosition}
⏱ <b>Стаж:</b> ${data.experience}

🏥 <b>Желаемая должность:</b> ${positions[data.desiredPosition] || data.desiredPosition}
💰 <b>Желаемая зарплата:</b> ${Number(data.salary).toLocaleString('ru-RU')} UZS

📞 <b>Телефон:</b> ${data.phone}
✉️ <b>Email:</b> ${data.email}`
    : `🦷 <b>Yangi ish arizasi</b>
📅 ${now}

👤 <b>F.I.O:</b> ${data.lastName} ${data.firstName} ${data.middleName}
🎂 <b>Tug'ilgan sana:</b> ${data.birthDate}
📍 <b>Tug'ilgan joy:</b> ${data.birthPlace}

🎓 <b>Ta'lim:</b> ${data.institution}
📚 <b>Mutaxassislik:</b> ${data.specialty}

💼 <b>Oxirgi ish joyi:</b> ${data.lastWork}
🏷 <b>Lavozim:</b> ${data.lastPosition}
⏱ <b>Staj:</b> ${data.experience}

🏥 <b>Istalgan lavozim:</b> ${positions[data.desiredPosition] || data.desiredPosition}
💰 <b>Istalgan maosh:</b> ${Number(data.salary).toLocaleString('ru-RU')} UZS

📞 <b>Telefon:</b> ${data.phone}
✉️ <b>Email:</b> ${data.email}`;
}

// Главная функция отправки
export async function submitApplication(formData, photoFile, lang) {
  const message = formatTelegramMessage(formData, lang);

  // Отправляем фото с подписью если есть, иначе просто текст
  if (photoFile) {
    await sendTelegramPhoto(photoFile, message);
  } else {
    await sendTelegramMessage(message);
  }

  // Сохраняем в Google Sheets
  await saveToGoogleSheets({ ...formData, lang, submittedAt: new Date().toISOString() });
}
