// ============================================================
//  НАСТРОЙКИ — заполните свои данные здесь
// ============================================================

// 1. Telegram Bot Token (получите у @BotFather)
//    Пример: "7123456789:AAFxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
export const TELEGRAM_BOT_TOKEN = "8981417143:AAFSUWkTaOyB3Hfp6pi2bbnr5cdXCqkBFYk";

// 2. Telegram Chat ID (куда приходят уведомления)
//    Ваш личный ID или ID группы. Узнайте через @userinfobot
//    Пример: "123456789"
export const TELEGRAM_CHAT_ID = "-5140791928";

// 3. Google Apps Script Web App URL
//    После деплоя вашего Apps Script вставьте URL сюда
//    Пример: "https://script.google.com/macros/s/AKfycb.../exec"
export const GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxjtlq8a2K6k3JeTyGbOcFABhH-oYWJCLzr--9SxyoOLHoQGWfmuZWyKg2-HSAXvCX3jg/exec";

// ============================================================
//  Название клиники (отображается в шапке и анкете)
// ============================================================
export const CLINIC_NAME = "UMID MEDICAL CENTREs";
