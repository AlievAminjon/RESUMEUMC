import React, { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { submitApplication } from './services/submission';
import './i18n';
import './App.css';

// ── Language Switcher ──────────────────────────────────────
function LanguageSwitcher() {
  const { i18n } = useTranslation();
  const current = i18n.language?.startsWith('uz') ? 'uz' : 'ru';

  return (
    <div className="lang-switcher">
      <button
        className={`lang-btn ${current === 'ru' ? 'active' : ''}`}
        onClick={() => i18n.changeLanguage('ru')}
      >
        <span className="flag">🇷🇺</span> RU
      </button>
      <button
        className={`lang-btn ${current === 'uz' ? 'active' : ''}`}
        onClick={() => i18n.changeLanguage('uz')}
      >
        <span className="flag">🇺🇿</span> UZ
      </button>
    </div>
  );
}

// ── Input Field ────────────────────────────────────────────
function Field({ label, error, children, required }) {
  return (
    <div className={`field ${error ? 'field--error' : ''}`}>
      <label className="field__label">
        {label}{required && <span className="required">*</span>}
      </label>
      {children}
      {error && <span className="field__error">{error}</span>}
    </div>
  );
}

// ── Section Header ─────────────────────────────────────────
function SectionTitle({ icon, title }) {
  return (
    <div className="section-title">
      <span className="section-icon">{icon}</span>
      <h3>{title}</h3>
    </div>
  );
}

// ── Success Screen ─────────────────────────────────────────
function SuccessScreen({ onReset }) {
  const { t } = useTranslation();
  return (
    <div className="success-screen">
      <div className="success-icon">
        <svg viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="40" cy="40" r="38" stroke="#2A7BE4" strokeWidth="2.5"/>
          <path d="M24 40L35 51L56 30" stroke="#2A7BE4" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <h2 className="success-title">{t('success.title')}</h2>
      <p className="success-message">{t('success.message')}</p>
      <button className="btn-reset" onClick={onReset}>{t('success.back')}</button>
    </div>
  );
}

// ── Photo Uploader ─────────────────────────────────────────
function PhotoUpload({ value, onChange, error, t }) {
  const inputRef = useRef();

  const handleFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png'].includes(file.type)) {
      onChange(null, t('errors.invalidFormat'));
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      onChange(null, t('errors.fileTooLarge'));
      return;
    }
    const url = URL.createObjectURL(file);
    onChange(file, null, url);
  };

  return (
    <div className={`photo-upload ${error ? 'photo-upload--error' : ''} ${value?.url ? 'photo-upload--filled' : ''}`}
         onClick={() => inputRef.current.click()}>
      {value?.url ? (
        <div className="photo-preview">
          <img src={value.url} alt="preview" />
          <div className="photo-overlay">
            <span>{t('form.photo.change')}</span>
          </div>
        </div>
      ) : (
        <div className="photo-placeholder">
          <div className="photo-icon">
            <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="4" y="10" width="40" height="30" rx="4" stroke="currentColor" strokeWidth="2"/>
              <circle cx="24" cy="25" r="7" stroke="currentColor" strokeWidth="2"/>
              <path d="M18 10l2-4h8l2 4" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
            </svg>
          </div>
          <span className="photo-label">{t('form.photo.label')}</span>
          <span className="photo-hint">{t('form.photo.hint')}</span>
        </div>
      )}
      <input ref={inputRef} type="file" accept="image/jpeg,image/png" onChange={handleFile} hidden />
      {error && <span className="field__error photo-error">{error}</span>}
    </div>
  );
}

// ── Main App ───────────────────────────────────────────────
export default function App() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language?.startsWith('uz') ? 'uz' : 'ru';

  const [photo, setPhoto] = useState(null);
  const [photoError, setPhotoError] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const initialForm = {
    firstName: '', lastName: '', middleName: '',
    birthDate: '', birthPlace: '',
    institution: '', specialty: '',
    lastWork: '', lastPosition: '', experience: '',
    desiredPosition: '', salary: '',
    phone: '', email: '',
  };
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});

  const handlePhotoChange = (file, err, url) => {
    setPhotoError(err || '');
    setPhoto(file ? { file, url } : null);
  };

  const set = (key) => (e) => {
    setForm(f => ({ ...f, [key]: e.target.value }));
    if (errors[key]) setErrors(er => ({ ...er, [key]: '' }));
  };

  const validate = () => {
    const errs = {};
    const req = ['firstName','lastName','birthDate','birthPlace','institution','specialty',
                  'lastWork','lastPosition','experience','desiredPosition','salary','phone','email'];
    req.forEach(k => { if (!form[k].trim()) errs[k] = t('errors.required'); });
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = t('errors.invalidEmail');
    if (!photo) setPhotoError(t('errors.photoRequired'));
    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0 || !photo) return;

    setLoading(true);
    setSubmitError('');
    try {
      await submitApplication(form, photo.file, lang);
      setSubmitted(true);
    } catch (err) {
      console.error(err);
      setSubmitError(t('errors.sendError'));
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setSubmitted(false);
    setForm(initialForm);
    setPhoto(null);
    setErrors({});
    setPhotoError('');
    setSubmitError('');
  };

  const positions = ['dentist','assistant','admin','nurse','marketer','other'];

  return (
    <div className="app">
      {/* ── Header ── */}
      <header className="header">
        <div className="header__inner">
          <div className="logo">
            <div className="logo__icon">
               <img src="/logo.png" alt="logo" style={{height: '40px'}} />
            </div>
            <div className="logo__text">
              <span className="logo__name">Dental Clinic</span>
              <span className="logo__tag">{t('header.subtitle')}</span>
            </div>
          </div>
          <LanguageSwitcher />
        </div>
      </header>

      {/* ── Hero ── */}
      {!submitted && (
        <section className="hero">
          <div className="hero__bg">
            <div className="hero__blob hero__blob--1" />
            <div className="hero__blob hero__blob--2" />
          </div>
          <div className="hero__content">
            <span className="hero__badge">{t('hero.badge')}</span>
            <h1 className="hero__title">{t('hero.title')}</h1>
            <p className="hero__subtitle">{t('hero.subtitle')}</p>
            <a href="#form" className="hero__cta">{t('hero.cta')}</a>
          </div>
        </section>
      )}

      {/* ── Main ── */}
      <main className="main" id="form">
        {submitted ? (
          <SuccessScreen onReset={handleReset} />
        ) : (
          <div className="form-card">
            <div className="form-card__header">
              <h2 className="form-card__title">{t('form.title')}</h2>
              <p className="form-card__subtitle">{t('form.subtitle')}</p>
            </div>

            <form onSubmit={handleSubmit} noValidate>

              {/* Photo */}
              <div className="form-section">
                <PhotoUpload value={photo} onChange={handlePhotoChange} error={photoError} t={t} />
              </div>

              {/* Personal */}
              <div className="form-section">
                <SectionTitle icon="👤" title={t('form.personal.section')} />
                <div className="grid grid--3">
                  <Field label={t('form.personal.lastName')} error={errors.lastName} required>
                    <input className="input" value={form.lastName} onChange={set('lastName')} placeholder={t('form.placeholders.lastName')} />
                  </Field>
                  <Field label={t('form.personal.firstName')} error={errors.firstName} required>
                    <input className="input" value={form.firstName} onChange={set('firstName')} placeholder={t('form.placeholders.firstName')} />
                  </Field>
                  <Field label={t('form.personal.middleName')} error={errors.middleName}>
                    <input className="input" value={form.middleName} onChange={set('middleName')} placeholder={t('form.placeholders.middleName')} />
                  </Field>
                </div>
                <div className="grid grid--2">
                  <Field label={t('form.personal.birthDate')} error={errors.birthDate} required>
                    <input className="input" type="date" value={form.birthDate} onChange={set('birthDate')} />
                  </Field>
                  <Field label={t('form.personal.birthPlace')} error={errors.birthPlace} required>
                    <input className="input" value={form.birthPlace} onChange={set('birthPlace')} placeholder={t('form.placeholders.birthPlace')} />
                  </Field>
                </div>
              </div>

              {/* Education */}
              <div className="form-section">
                <SectionTitle icon="🎓" title={t('form.education.section')} />
                <div className="grid grid--2">
                  <Field label={t('form.education.institution')} error={errors.institution} required>
                    <input className="input" value={form.institution} onChange={set('institution')} placeholder={t('form.placeholders.institution')} />
                  </Field>
                  <Field label={t('form.education.specialty')} error={errors.specialty} required>
                    <input className="input" value={form.specialty} onChange={set('specialty')} placeholder={t('form.placeholders.specialty')} />
                  </Field>
                </div>
              </div>

              {/* Experience */}
              <div className="form-section">
                <SectionTitle icon="💼" title={t('form.experience.section')} />
                <div className="grid grid--3">
                  <Field label={t('form.experience.lastWork')} error={errors.lastWork} required>
                    <input className="input" value={form.lastWork} onChange={set('lastWork')} placeholder={t('form.placeholders.lastWork')} />
                  </Field>
                  <Field label={t('form.experience.position')} error={errors.lastPosition} required>
                    <input className="input" value={form.lastPosition} onChange={set('lastPosition')} placeholder={t('form.placeholders.position')} />
                  </Field>
                  <Field label={t('form.experience.experience')} error={errors.experience} required>
                    <input className="input" value={form.experience} onChange={set('experience')} placeholder={t('form.placeholders.experience')} />
                  </Field>
                </div>
              </div>

              {/* Desired job */}
              <div className="form-section">
                <SectionTitle icon="🏥" title={t('form.job.section')} />
                <div className="grid grid--2">
                  <Field label={t('form.job.section')} error={errors.desiredPosition} required>
                    <select className="input select" value={form.desiredPosition} onChange={set('desiredPosition')}>
                      <option value="">{t('form.job.desired')}</option>
                      {positions.map(p => (
                        <option key={p} value={p}>{t(`form.job.positions.${p}`)}</option>
                      ))}
                    </select>
                  </Field>
                  <Field label={t('form.job.salary')} error={errors.salary} required>
                    <div className="input-currency">
                      <input className="input" type="number" value={form.salary} onChange={set('salary')} placeholder={t('form.placeholders.salary')} />
                      <span className="currency-badge">UZS</span>
                    </div>
                  </Field>
                </div>
              </div>

              {/* Contacts */}
              <div className="form-section">
                <SectionTitle icon="📞" title={t('form.contacts.section')} />
                <div className="grid grid--2">
                  <Field label={t('form.contacts.phone')} error={errors.phone} required>
                    <input className="input" type="tel" value={form.phone} onChange={set('phone')} placeholder={t('form.placeholders.phone')} />
                  </Field>
                  <Field label={t('form.contacts.email')} error={errors.email} required>
                    <input className="input" type="email" value={form.email} onChange={set('email')} placeholder={t('form.placeholders.email')} />
                  </Field>
                </div>
              </div>

              {submitError && <div className="submit-error">{submitError}</div>}

              <button className="btn-submit" type="submit" disabled={loading}>
                {loading ? (
                  <><span className="spinner" /> {t('form.submitting')}</>
                ) : t('form.submit')}
              </button>
            </form>
          </div>
        )}
      </main>

      <footer className="footer">
        <p>© {new Date().getFullYear()} Dental Clinic</p>
      </footer>
    </div>
  );
}
