// ============================================================
//  Google Apps Script — Dental Clinic Job Applications
//  Вставьте этот код в: script.google.com → New Project
// ============================================================

// ID вашей Google Таблицы (из URL: .../spreadsheets/d/ЭТОТ_ID/...)
const SPREADSHEET_ID = 'ВАШ_SPREADSHEET_ID';

// Название листа (Sheet1 по умолчанию)
const SHEET_NAME = 'Заявки';

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const sheet = SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName(SHEET_NAME)
                  || SpreadsheetApp.openById(SPREADSHEET_ID).insertSheet(SHEET_NAME);

    // Заголовки (только при первой записи)
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        'Дата', 'Фамилия', 'Имя', 'Отчество', 'Дата рождения', 'Место рождения',
        'Учебное заведение', 'Специальность',
        'Последнее место работы', 'Должность', 'Стаж',
        'Желаемая должность', 'Желаемая зарплата (UZS)',
        'Телефон', 'Email', 'Язык'
      ]);
      // Стиль заголовков
      sheet.getRange(1, 1, 1, 16).setFontWeight('bold').setBackground('#1a4080').setFontColor('#ffffff');
    }

    // Добавить строку
    sheet.appendRow([
      new Date().toLocaleString('ru-RU'),
      data.lastName || '',
      data.firstName || '',
      data.middleName || '',
      data.birthDate || '',
      data.birthPlace || '',
      data.institution || '',
      data.specialty || '',
      data.lastWork || '',
      data.lastPosition || '',
      data.experience || '',
      data.desiredPosition || '',
      data.salary || '',
      data.phone || '',
      data.email || '',
      data.lang || 'ru'
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ status: 'ok' }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// Для теста в браузере
function doGet() {
  return ContentService.createTextOutput('Apps Script работает ✓');
}
